package com.employee.details.NettyKafkaProtoBuilder.proto;


import org.apache.kafka.common.serialization.Serializer;

import com.employee.details.NettyKafkaProtoBuilder.proto.EmployeeDetailBean.EmployeeDetails;

public class EmployeeDetailsBeanSerializer extends Adapter implements Serializer<EmployeeDetails> {

	@Override
	/*
	 * To serilise    the Informations befor  pushing into kafka 
	*/
	public byte[] serialize(String topic, EmployeeDetails detailsBean) {
		return detailsBean.toByteArray();
	}
}