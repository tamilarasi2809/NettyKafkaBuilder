package com.employee.details.NettyKafkaProtoBuilder.kafka;


import java.util.Properties;

//import KafkaProducer packages
import org.apache.kafka.clients.producer.KafkaProducer;
//import simple producer packages
import org.apache.kafka.clients.producer.Producer;
//import ProducerRecord packages
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.json.JSONObject;

import com.employee.details.NettyKafkaProtoBuilder.proto.EmployeeDetailBean;
import com.employee.details.NettyKafkaProtoBuilder.proto.EmployeeDetailBean.EmployeeDetails;
import com.employee.details.NettyKafkaProtoBuilder.proto.EmployeeDetailsBeanSerializer;




public class EmployeeDetailsProducer {
 
 public void run(JSONObject obj) throws Exception{
    
    System.err.println(" Step 3 :Entering Producer class to push the details into kafka queue ");
    String topicName = "EmployeeDetails";
    Properties props = new Properties();
    
    props.put("bootstrap.servers", "localhost:9092");
    
    props.put("acks", "all");
   
    props.put("retries", 0);

    props.put("batch.size", 16384);
   
    props.put("linger.ms", 1);
   
    props.put("buffer.memory", 33554432);
    props.put("key.serializer", 
    	       "com.employee.details.proto.EmployeeDetailsBeanSerializer");
    	    props.put("value.serializer", 
    	       "com.employee.details.proto.EmployeeDetailsBeanSerializer");
    EmployeeDetails detailsBean = null;
    try{
        detailsBean = EmployeeDetailBean.EmployeeDetails.newBuilder()
				.setName(obj.getString("name"))
				.setEmployeeId(obj.getString("employeeId"))
				.setSalary(obj.getString("salary"))
				.setEmailId(obj.getString("emailId"))		
				.setDesignation(obj.getString("designation")).build();

        Producer<String, EmployeeDetails> producer = new KafkaProducer
        	       <String, EmployeeDetails>(props,new StringSerializer(), new EmployeeDetailsBeanSerializer());
        	       producer.send(new ProducerRecord<String, EmployeeDetails>(topicName,detailsBean ));
             System.err.println("Step 4 : Message sent successfully");
             producer.close();
 }catch(Exception e ){
 	e.printStackTrace();
 }
 finally{
 	detailsBean = null;
 }
}
}