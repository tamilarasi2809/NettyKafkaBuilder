SampleURL:http://localhost:8082/?name=Tamil&employeeId=1&salary=50000.34&emailId=tamil2801@gmail.com&designation=ProgrammerAnalyst
Topic:EmployeeDetails
